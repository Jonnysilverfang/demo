export class ListFriend {}
