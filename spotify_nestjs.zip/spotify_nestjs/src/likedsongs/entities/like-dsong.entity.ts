export class LikeDsong {}
