export class RecentSong {}
