export class CreateGenreDto {}
